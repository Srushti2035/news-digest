const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');
const { generateDigest } = require('../services/digestService');

// Get User Profile
router.get('/profile', auth, async (req, res) => {
    const user = await User.findById(req.user.userId);
    res.json(user);
});

// Update Topics & Subscription
router.patch('/update-preferences', auth, async (req, res) => {
    const { topics, isSubscribed } = req.body;
    const user = await User.findByIdAndUpdate(
        req.user.userId,
        { topics, isSubscribed },
        { new: true }
    );
    res.json(user);
});

// Manual Trigger: Send Now
router.post('/send-now', auth, async (req, res) => {
    await generateDigest(req.user.userId);
    res.json({ message: "Digest sent successfully!" });
});

module.exports = router;