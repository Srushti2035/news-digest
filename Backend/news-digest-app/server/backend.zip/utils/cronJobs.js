const cron = require('node-cron');
const User = require('../models/User');
const { generateDigest } = require('../services/digestService');

const initCronJobs = () => {
    // Every 5 minutes for testing
    cron.schedule('*/5 * * * *', async () => {
        console.log("Running scheduled news delivery...");
        const users = await User.find({ isSubscribed: true });
        for (const user of users) {
            await generateDigest(user._id);
        }
    });
};

module.exports = initCronJobs;