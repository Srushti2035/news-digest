const axios = require('axios');
const SibApiV3Sdk = require('sib-api-v3-sdk');
const User = require('../models/User');

// Configure Brevo (Sendinblue)
const defaultClient = SibApiV3Sdk.ApiClient.instance;
const apiKey = defaultClient.authentications['api-key'];
apiKey.apiKey = process.env.BREVO_API_KEY;
const apiInstance = new SibApiV3Sdk.TransactionalEmailsApi();

const generateDigest = async (userId) => {
    try {
        const user = await User.findById(userId);
        if (!user || user.topics.length === 0) return;

        let newsContent = `<h1>Your Daily News Digest</h1>`;

        // 1. Fetch News for each topic
        for (const topic of user.topics) {
            const response = await axios.get(`https://newsapi.org/v2/everything?q=${topic}&pageSize=3&apiKey=${process.env.NEWS_API_KEY}`);
            const articles = response.data.articles;

            newsContent += `<h2>Topic: ${topic}</h2><ul>`;
            articles.forEach(art => {
                newsContent += `<li><a href="${art.url}">${art.title}</a></li>`;
            });
            newsContent += `</ul>`;
        }

        // 2. Send Email via Brevo
        const sendSmtpEmail = {
            sender: { email: "machanna037@gmail.com", name: "News Digest" },
            to: [{ email: user.email }],
            subject: "Your Personalized News Digest",
            htmlContent: `<html><body>${newsContent}</body></html>`
        };

        await apiInstance.sendTransacEmail(sendSmtpEmail);
        console.log(`Email sent to ${user.email}`);
    } catch (error) {
        console.error("Error in generateDigest:", error.message);
    }
};

module.exports = { generateDigest };