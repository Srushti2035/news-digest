import React, { useEffect, useState } from 'react';
import { getProfile, updatePreferences, sendNow } from '../api';
import { Trash2, Send, Bell, BellOff } from 'lucide-react';

const Dashboard = () => {
    const [user, setUser] = useState(null);
    const [newTopic, setNewTopic] = useState('');

    useEffect(() => {
        fetchProfile();
    }, []);

    const fetchProfile = async () => {
        const { data } = await getProfile();
        setUser(data);
    };

    const handleUpdate = async (updatedFields) => {
        const { data } = await updatePreferences({ ...user, ...updatedFields });
        setUser(data);
    };

    const addTopic = () => {
        if (!newTopic) return;
        const updatedTopics = [...user.topics, newTopic];
        handleUpdate({ topics: updatedTopics });
        setNewTopic('');
    };

    const removeTopic = (topicToRemove) => {
        const updatedTopics = user.topics.filter(t => t !== topicToRemove);
        handleUpdate({ topics: updatedTopics });
    };

    const triggerManualMail = async () => {
        alert("Sending your digest now...");
        await sendNow();
        alert("Digest Sent!");
    };

    if (!user) return <div className="p-10 text-center text-white">Loading...</div>;

    return (
        <div className="min-h-screen bg-gray-900 text-white p-8">
            <div className="max-w-2xl mx-auto bg-gray-800 p-6 rounded-xl shadow-lg">
                <h1 className="text-3xl font-bold mb-6 text-blue-400">News Preferences</h1>

                {/* Topic Input */}
                <div className="flex gap-2 mb-6">
                    <input
                        className="flex-1 p-2 rounded bg-gray-700 border border-gray-600 outline-none"
                        placeholder="Add a topic (e.g. AI, Cricket)"
                        value={newTopic}
                        onChange={(e) => setNewTopic(e.target.value)}
                    />
                    <button onClick={addTopic} className="bg-blue-600 px-4 py-2 rounded font-bold hover:bg-blue-500">Add</button>
                </div>

                {/* Topics List */}
                <div className="flex flex-wrap gap-2 mb-8">
                    {user.topics.map(topic => (
                        <span key={topic} className="flex items-center gap-2 bg-gray-700 px-3 py-1 rounded-full border border-blue-500/30">
                            {topic}
                            <Trash2 size={16} className="text-red-400 cursor-pointer" onClick={() => removeTopic(topic)} />
                        </span>
                    ))}
                </div>

                {/* Subscription Toggle */}
                <div className="flex items-center justify-between border-t border-gray-700 pt-6">
                    <div className="flex items-center gap-3">
                        {user.isSubscribed ? <Bell className="text-green-400" /> : <BellOff className="text-gray-400" />}
                        <span className="font-semibold">{user.isSubscribed ? "Subscribed to Daily Email" : "Subscription Off"}</span>
                    </div>
                    <button
                        onClick={() => handleUpdate({ isSubscribed: !user.isSubscribed })}
                        className={`px-6 py-2 rounded-full font-bold transition ${user.isSubscribed ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'}`}
                    >
                        {user.isSubscribed ? "Disable" : "Enable"}
                    </button>
                </div>

                {/* Manual Trigger */}
                <button
                    onClick={triggerManualMail}
                    className="w-full mt-8 flex items-center justify-center gap-2 bg-indigo-600 p-3 rounded-lg font-bold hover:bg-indigo-500"
                >
                    <Send size={18} /> Send Digest Now
                </button>
            </div>
        </div>
    );
};

export default Dashboard;