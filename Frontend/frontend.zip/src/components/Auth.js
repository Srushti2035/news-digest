import React, { useState } from 'react';
import { login, register } from '../api';
import { useNavigate } from 'react-router-dom';

const Auth = ({ isLogin }) => {
    const [formData, setFormData] = useState({ email: '', password: '' });
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (isLogin) {
                const { data } = await login(formData);
                localStorage.setItem('token', data.token);
                navigate('/dashboard');
            } else {
                await register(formData);
                alert("Registered! Please login.");
                navigate('/');
            }
        } catch (err) {
            alert(err.response?.data?.message || "Something went wrong");
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white">
            <form onSubmit={handleSubmit} className="bg-gray-800 p-8 rounded-lg shadow-xl w-96">
                <h2 className="text-2xl font-bold mb-6 text-center">{isLogin ? 'Login' : 'Register'}</h2>
                <input
                    type="email" placeholder="Email" required
                    className="w-full p-2 mb-4 bg-gray-700 border border-gray-600 rounded"
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
                <input
                    type="password" placeholder="Password" required
                    className="w-full p-2 mb-6 bg-gray-700 border border-gray-600 rounded"
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
                <button className="w-full bg-blue-600 p-2 rounded font-bold hover:bg-blue-500">
                    {isLogin ? 'Login' : 'Sign Up'}
                </button>
                <p className="mt-4 text-sm text-gray-400 cursor-pointer text-center" onClick={() => navigate(isLogin ? '/register' : '/')}>
                    {isLogin ? "Need an account? Register" : "Have an account? Login"}
                </p>
            </form>
        </div>
    );
};

export default Auth;