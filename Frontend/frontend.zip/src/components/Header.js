import { Grid } from "@mui/material";
import React from "react";
const Header = () => {
  return (
    <Grid container>
      <Grid item md={3}>
        Hoi
      </Grid>
      <Grid item md={3}>
        Hello   
      </Grid>
    </Grid>
  );
};

export default Header;
